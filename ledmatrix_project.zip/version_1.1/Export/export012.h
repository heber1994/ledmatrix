#ifndef export0012_h
#define export0012_h
const uint8_t storetoflash12[1][1] PROGMEM = {
{0x00}
};
#endif