#ifndef export0018_h
#define export0018_h
const uint8_t storetoflash18[1][1] PROGMEM = {
{0x00}
};
#endif