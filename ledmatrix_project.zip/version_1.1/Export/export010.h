#ifndef export0010_h
#define export0010_h
const uint8_t storetoflash10[1][1] PROGMEM = {
{0x00}
};
#endif