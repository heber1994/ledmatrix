#ifndef export0020_h
#define export0020_h
const uint8_t storetoflash20[1][1] PROGMEM = {
{0x00}
};
#endif