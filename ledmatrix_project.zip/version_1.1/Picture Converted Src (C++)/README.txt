if errors/bugs are found, please delete the main.exe file in ledmatrix_project\version_1.1\
then edit the code in main.cpp and customheaders/bmpreadclass.h to fix the bug.

recompile using

make clean; make gnucompile

then copy the executable file in ledmatrix_project\version_1.1\

ignore the Import and Export folders under Picture Converted Src (C++). these folders are only used to test the main.exe file before using it with the other C program.